export interface Student {
  name: string;
  age: number;
  dateofbirth: string;
  email: string;
}
